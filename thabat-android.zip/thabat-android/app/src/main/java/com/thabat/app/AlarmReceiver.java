package com.thabat.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        Notifs.show(c, i.getStringExtra("title"), i.getStringExtra("body"));
    }
}
