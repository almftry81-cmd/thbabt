package com.thabat.app;

import android.app.Activity;
import android.os.Build;
import android.webkit.JavascriptInterface;

public class Bridge {
    private final Activity a;

    Bridge(Activity a) { this.a = a; }

    @JavascriptInterface
    public void show(String title, String body) { Notifs.show(a, title, body); }

    @JavascriptInterface
    public void schedule(String json) { Notifs.schedule(a, json); }

    @JavascriptInterface
    public void requestPermission() {
        a.runOnUiThread(() -> {
            if (Build.VERSION.SDK_INT >= 33) {
                a.requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 2);
            }
        });
    }
}
