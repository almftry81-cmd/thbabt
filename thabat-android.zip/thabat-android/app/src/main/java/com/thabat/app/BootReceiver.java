package com.thabat.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        String l = c.getSharedPreferences("n", 0).getString("list", null);
        if (l != null) Notifs.schedule(c, l);
    }
}
